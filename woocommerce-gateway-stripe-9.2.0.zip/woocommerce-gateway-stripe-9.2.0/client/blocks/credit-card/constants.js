export const PAYMENT_METHOD_NAME = 'stripe';
export const WC_STORE_CART = 'wc/store/cart';
