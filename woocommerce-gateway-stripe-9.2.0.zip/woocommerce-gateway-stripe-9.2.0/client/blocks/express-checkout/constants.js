export const PAYMENT_METHOD_EXPRESS_CHECKOUT_ELEMENT =
	'express_checkout_element';
