export const RECONNECT_BANNER = 'stripe-reconnect';
export const NEW_CHECKOUT_EXPERIENCE_BANNER = 'new-checkout-experience';
